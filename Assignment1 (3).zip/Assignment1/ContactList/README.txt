Important Files in the folder are:

1)ContactList/src/ContactList.java

Contains the code
---------------------------------------------
2)input1.txt 

Writes the input in it and saves it for future reading of it.
Every time input is written as given in bufferwriter format it will go to this .txt file

----------------------------------------------


Classes in it are:

1)Relatives
2)Personal
3)Professional
4)Casual
5)MyException
6)ContactList
Classes in ContactList: 1)sum
                        2)main(String[])