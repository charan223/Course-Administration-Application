Important Files in the folder are:
1)CourseList/src/CourseList.java 

Main Code contains in this

----------------------------------------------------------
 
2)CourseList/input1.txt

Writes the input in it and saves it for future reading of it.
Every time input is written in buffer format it will go to this .txt file

---------------------------------------------------------


Classes in it are:

1)Participants
2)Faculty
3)Course
4)MyException
4)CourseList---contains
1) main(String[])-main class
2)sum
-----------------------------------------------------------
